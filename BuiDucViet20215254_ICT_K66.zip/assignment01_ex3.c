#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include"student.h"
void EnterList(student std[],int n,int a){
    for(int i=n;i<n+a;i++){
        printf("Enter the name of the student: ");
        fseek(stdin,0,SEEK_END);
        scanf("%[^\n]",std[i].name);
        printf("Enter the score: ");
        scanf("%f",&std[i].score);
    }
    FILE* f1;
    f1=fopen("SV2023.dat","ab");
    for(int i=n;i<n+a;i++){
        fwrite(&std[i],sizeof(student),1,f1);
    }
    fclose(f1);
}
void PrintList(student std[],int n){
    FILE* f2;
    f2=fopen("SV2023.dat","rb");
    for(int i=0;i<n;i++){
        fread(&std[i],sizeof(student),1,f2);
    }
    fclose(f2);
    printf("%-25s%s\n","Student Name","Score");
for(int i=0;i<n;i++){
     printf("%-25s%.2f\n",std[i].name,std[i].score);
}
}
void Search(student std[],int n){
    FILE *f3;
    f3=fopen("output.txt","w");
    char s_name[31];
    printf("Enter the name: ");
    fseek(stdin,0,SEEK_END);
    scanf("%[^\n]",s_name);
    printf("%-10s%-10s\n","Student Name","Score");
    for(int i=0;i<n;i++){
       if(strcmp(s_name,std[i].name)==0){
        printf("%-10s%-10.2f\n",std[i].name,std[i].score);
        fprintf(f3,"%s %f\n",std[i].name,std[i].score);
       }
    }
}
int main(){
    int choice;
    student std[1000];
    int a;
    int n=0;
    do{
        printf("============================\n");
        printf("=1. Add list of student    =\n");
        printf("=2. Print list of student  =\n");
        printf("=3. Search student by name =\n");
        printf("=4. Exit                   =\n");
        printf("============================\n");
        printf("Enter your choice: ");
        scanf("%d",&choice);
        switch(choice){
            case 1:
            printf("Enter the number of student: ");
            scanf("%d",&a);
            EnterList(std,n,a);
            n=n+a;
            break;
            case 2:
            PrintList(std,n);
            break;
            case 3:
            Search(std,n);
            break;
            default:
            break;
        }
    }while(choice !=4);
    printf("Goodbye!");
return 0;
}
