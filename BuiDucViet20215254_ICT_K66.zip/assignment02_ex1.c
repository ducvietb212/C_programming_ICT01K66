#include<stdio.h>
int check(int a[],int i,int n){
int sum1=0;
for(int j=0;j<i;j++){
    sum1=sum1+a[j];
}
int sum2=0;
for(int j=i+1;j<n;j++){
    sum2=sum2+a[j];
}
if(sum1==sum2){
return 1;
}
else{
    return 0;
}
}
int main(){
    int n;
    int a[1000];
    scanf("%d",&n);
    for(int i=0;i<n;i++){
        scanf("%d",&a[i]);
    }
    for(int i=0;i<n;i++){
        if(check(a,i,n)==1){
            printf("YES\n");
            return 0;
        }
    }
    printf("NO\n");
    return 0;
}