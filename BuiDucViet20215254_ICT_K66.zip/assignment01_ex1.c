#include<stdio.h> 
    long int comb(int n,int k){
    int comb=1;
    for(int i=1;i<=k;i++,n--){
        comb=comb*n/i;
    }
    return comb;
}
int main(){
    FILE *fpin=NULL;
    FILE *fpout=NULL;
    int n,k;
    fpin=fopen("TOHOP.inp","r");
    fpout=fopen("TOHOP.out","w");
    while(fscanf(fpin,"%d %d",&n,&k)!=EOF){
    fprintf(fpout,"%d\n",comb(n,k));
    }
    fclose(fpin);
    fclose(fpout);
    return 0;
}