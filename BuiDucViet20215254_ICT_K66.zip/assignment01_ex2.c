#include<stdio.h>
#include<math.h>
typedef struct object{
    int w;
    int v;
    char name;
}object;
    int total;//total weight of the bag
    int used;//the total weight that be used
    int remain;// the remaining weight of the bag;
    int m;//the number of types of object
    int fopt=-1;//the maximum value 
    int f=0;//the reecent value of the bag;
    int tempsol1[100],tempsol2[100],sol1[100],sol2[100];//sol1 for the number of each types of obj, sol2 for the name of the obj
    object obj[100];
void Try(int k){
    int yk;
    yk=remain/obj[k].w;
    for(int i=yk;i>=0;i--){
    tempsol1[k]=i;
    tempsol2[k]=obj[k].name;
    f=f+yk*obj[k].v;
    remain=remain-yk*obj[k].w;
    if(k==m){
        if(f>fopt){
            fopt=f;
            for(int i=1;i<=m;i++){
                if(tempsol1[i]!=0){
                    sol1[i]=tempsol1[i];
                    sol2[i]=tempsol2[i];
                }
            }
        }
    }
    else{
        Try(k+1);
    }
    f=f-yk*obj[k].v;
    remain=remain-yk*obj[k].v;
}
}
int main(){
    FILE *fpin=NULL;
    FILE *fpout=NULL;
    fpin=fopen("BAG.inp","r");
    fscanf(fpin,"%d %d",&m,&total);
    remain=total;
    for(int i=1;i<=m;i++){
        fscanf(fpin,"%d %d %c",&obj[i].w,&obj[i].v,&obj[i].name);
    }
    for(int i=1;i<m;i++){
        for(int j=1;j<=m-i;j++){
         if(((float)obj[j].v/(float)obj[j].w)<((float)obj[j+1].v/(float)obj[j+1].w)){
            object tmp;
            tmp=obj[j];
            obj[j]=obj[j+1];
            obj[j+1]=tmp;
         }
        }
    }
    fclose(fpin);
    Try(1);
    fpout=fopen("BAG.out","w");
    fprintf(fpout,"%d\n",fopt);
    for(int i=m;i>1;i--){//Đổi lại thứ tự tên obj theo alphabet
        for(int j=1;j<i;j++){
            if(sol2[j]>sol2[j+1]){
                int tmp=sol2[j];
                sol2[j]=sol2[j+1];
                sol2[j+1]=tmp;
                int temp=sol1[j];
                sol1[j]=sol1[j+1];
                sol1[j+1]=temp;
            }
        }

    }
    for(int i=1;i<=m;i++){
        if(sol1[i]!=0){
            fprintf(fpout,"%c %d\n",sol2[i],sol1[i]);
        }
    }
    fclose(fpout);
    return 0;
}