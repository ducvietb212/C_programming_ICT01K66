#include<stdio.h>
#include<stdlib.h>
typedef struct{
    char name[31];
    float score;
}student;


