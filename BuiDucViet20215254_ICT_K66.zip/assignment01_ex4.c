#include<stdio.h>
#include<time.h>
#include<stdlib.h>
int main(){
    int c[52];
    for(int i=0;i<52;i++){
        c[i]=0;
    }
    int a[13][4];
    int x;
    for(int i=0;i<13;i++){
        for(int j=0;j<4;j++){
            a[i][j]=0;
        }
    }
    srand((int)time(0));
    for(int i=0;i<13;i++){
        for(int j=0;j<4;j++){
        do{
            x=rand()%52;
            if(c[x]==0){
            a[i][j]=x;
            }
        }while(c[x]==1);
        c[x]=1;
        }
    }
    char ch[][3]={"2","3","4","5","6","7","8","9","10","J","Q","K","A"};
    char ty[]={'H','D','S','C'};
    printf("\n\n\n");
    int check[4][13];//Check the four
    for(int j=0;j<4;j++){
        for(int i=0;i<13;i++){
            check[j][i]=0;
        }
    }
    for(int j=0;j<4;j++){
        printf("Player %d: ",j+1);
        for(int i=0;i<13;i++){
            printf("%s%-3c",ch[a[i][j]/4],ty[a[i][j]%4]);
            check[j][a[i][j]/4]++;
        }
        printf("\n");
    }
    for(int j=0;j<4;j++){
        for(int i=0;i<13;i++){
            if(check[j][i]==4){
                printf("The player %d has four %s card\n",j+1,ch[i]);
            }
        }
    }
    return 0;
}