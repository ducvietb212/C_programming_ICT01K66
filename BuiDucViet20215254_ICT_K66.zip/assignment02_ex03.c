#include <stdio.h>
#include <stdlib.h>
typedef struct {
    int d,m,y,h,mi,s;
    float temp;
}temperature;
int main(){
    temperature t[100];
    FILE *fp;
    fp=fopen("temp.dat","r");
    int i=0;
    while(fscanf(fp,"%d-%d-%d %d:%d:%d\n%f\n",&t[i].d,&t[i].m,&t[i].y,&t[i].h,&t[i].mi,&t[i].s,&t[i].temp)!=EOF){
        i++;
    }
    float ave1,ave2,n1,n2;
    ave1=ave2=n1=n2=0;
    for(int j=0;j<i;j++){
        if(t[j].h>5&&t[j].h<16){
            ave1+=t[j].temp;
            n1++;
        }
        if(t[j].h>16&&t[j].h<22){
            ave2+=t[j].temp;
            n2++;
        }
    }
    for(int k=0;k<i;k++){
        printf("%d ",t[k].h);
    }
    printf("%f %f\n",ave1,ave2);
    printf("The average temperature from 5h00 to 15h59 is %.3f\n",ave1/n1);
    printf("The average temperature from 16h00 to 21h59 is: %.3f\n",ave2/n2);
    return 0;
}
