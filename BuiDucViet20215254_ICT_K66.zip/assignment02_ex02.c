#include<stdio.h>
#include<time.h>
#include<stdlib.h>
int main(){
    int x;
    int choice;
    srand((int)time(0));
    x=rand()%100+1;
    do{
    printf("Guess the number: ");
    scanf("%d",&choice);
    if(choice==x){
        printf("Correct!\n");
    }
    else if(choice<x){
        printf("The number is too low\n");
    }
    else{
        printf("The number is too high\n");
    }
    }while(choice!=x);
    return 0;
}